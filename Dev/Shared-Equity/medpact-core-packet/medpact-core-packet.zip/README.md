# MedPact Core (Foundation App)
A foundation application for MedPact’s data-intelligent platform:
- Multi-tenant organization model
- RBAC (roles/permissions-ready)
- Audit logging
- Ingestion job scaffolding (file-based for MVP)
- Metric Registry scaffolding
- API-first architecture

## Tech
- .NET 8 (ASP.NET Core Web API)
- EF Core (PostgreSQL recommended)
- Docker Compose for local infrastructure

## Getting started (local)
### 1) Requirements
- .NET SDK 8.x
- Docker Desktop (optional but recommended)

### 2) Configure environment
Copy `.env.example` to `.env` and adjust values if needed.

### 3) Start infrastructure (Postgres)
```bash
docker compose up -d
```

### 4) Run API
```bash
cd apps/api/MedPact.Api
dotnet restore
dotnet run
```

### 5) Apply migrations
This repo ships with entity models and DbContext. Create migrations on your machine:
```bash
cd apps/api/MedPact.Api
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate -p ../MedPact.Infrastructure -s .
dotnet ef database update -p ../MedPact.Infrastructure -s .
```

## Authentication (dev scaffold)
This repo includes a simple dev JWT login endpoint:
- `POST /api/auth/login` with `{ "email": "...", "tenantId": "..." }`
- Returns a JWT signed with `JWT__Key` from `.env` / user-secrets.

**Important:** This is for scaffolding only. Swap to Azure AD B2C / Auth0 / OpenIddict for production.

## Postman
Import `docs/MedPactCore.postman_collection.json` and set:
- `baseUrl`
- `tenantId`
- `token`

## License
Proprietary (MedPact).
